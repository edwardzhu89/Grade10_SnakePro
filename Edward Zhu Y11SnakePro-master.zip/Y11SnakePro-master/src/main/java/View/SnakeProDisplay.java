package View;

import Controller.SnakeProBrain;
import Model.SnakeProData;
import Model.Preferences;

import java.awt.*;

import Model.BoardCell;
import java.util.*;


/**
 * Controller.SnakeProBrain - The "View" in MVC
 * 
 * @author CS60 instructors
 */
public class SnakeProDisplay {

	/** reference to the board/snakePro data being drawn */
	private SnakeProData theData;
	
	/** the display where the board is drawn */
	private Graphics theScreen;
	
	/** width of the display in pixels */
	private int width;
	
	/** height of the display in pixels */
	public int height;
	
	/** a picture of a can of food */
	public static Image imageFood;

	/** Constructor
	 * 
	 * @param theBoardInput    the data being displayed
	 * @param theScreenInput  the display to draw the board
	 * @param widthInput      width of the display (in pixels)
	 * @param heightInput     height of the display (in pixels)
	 */
	public SnakeProDisplay(SnakeProData theBoardInput, Graphics theScreenInput,
						   int widthInput, int heightInput) {
		this.theScreen = theScreenInput;
		this.theData   = theBoardInput;
		this.height    = heightInput;
		this.width     = widthInput;
	}

	/* -------------------- */
	/* Displaying the board */
	/* -------------------- */
	
	/**
	 * Re-draws the board, food, and snake (but not the buttons).
	 */
	public void updateGraphics() {
		// Draw the background. DO NOT REMOVE!
		this.clear();

		// Draw the title
		this.displayTitle();

		// Draw the board and snake
		// TODO: Add your code here :) 
		// The method drawSquare (below) will likely be helpful :)

		// Drawing the white board
		for (int i=0;i<this.width;i+=Preferences.CELL_SIZE) {
			for (int j = 0; j < this.height - 6 * Preferences.CELL_SIZE; j += Preferences.CELL_SIZE) {
				if (i == 0 || j == 0 || i > this.width - 2 * Preferences.CELL_SIZE || j > this.height - 8 * Preferences.CELL_SIZE) {
					drawSquare(i, j, Color.BLUE);
				} else if (theData.getCell(i / 10, j / 10).isFood()) {
					drawSquare(i, j, Color.ORANGE);
				} else {
					drawSquare(i, j, Color.WHITE);
				}
			}
		}

		// Drawing the snake head
		BoardCell head = theData.getSnakeHead();
		drawSquare(head.getRow()*10,head.getColumn()*10,Color.BLACK);


		// Drawing snake body
		ArrayList<BoardCell> a = theData.getBody();
		for(int i=0;i<a.size()-1;i++){
			drawSquare(a.get(i).getRow()*10,a.get(i).getColumn()*10,Color.GREEN);
		}

		// Draw the game-over message, if appropriate.
		if (this.theData.getGameOver()) {
			this.displayGameOver();
		}
		this.theScreen.setFont(new Font("Helvetica", Font.PLAIN, 20));
		this.theScreen.setColor(Color.BLACK);
		this.theScreen.drawString("Score "+ theData.currScore,5,105);

	}

	/**
	 * Draws a cell-sized square with its upper-left corner
	 * at the given pixel coordinates (i.e., x pixels to the right and 
	 * y pixels below the upper-left corner) on the display.
	 * 
	 * @param x  x-coordinate of the square, between 0 and this.width-1 inclusive
	 * @param y  y-coordinate of the square, between 0 and this.width-1 inclusive
	 * @param cellColor  color of the square being drawn
	 */
	public void drawSquare(int x, int y, Color cellColor) {
		this.theScreen.setColor(cellColor);
		this.theScreen.fillRect(x, y, Preferences.CELL_SIZE,
				Preferences.CELL_SIZE);
	}

	/**
	 * Draws the background. DO NOT MODIFY!
	 */
	void clear() {
		this.theScreen.setColor(Preferences.COLOR_BACKGROUND);
		this.theScreen.fillRect(0, 0, this.width, this.height);
		this.theScreen.setColor(Preferences.TITLE_COLOR);
		this.theScreen.drawRect(0, 0, this.width - 1,
				Preferences.GAMEBOARDHEIGHT - 1);
	}

	/* ------------ */
	/* Text Display */
	/* ------------ */
	
	/**
	 * Displays the title of the game.
	 */
	public void displayTitle() {
		this.theScreen.setFont(Preferences.TITLE_FONT);
		this.theScreen.setColor(Preferences.TITLE_COLOR);
		this.theScreen.drawString(Preferences.TITLE, 
				Preferences.TITLE_X, Preferences.TITLE_Y);
	}

	/**
	 * Displays the game-over message.
	 */
	public void displayGameOver() {
		this.theScreen.setFont(Preferences.GAME_OVER_FONT);
		this.theScreen.setColor(Preferences.GAME_OVER_COLOR);
		this.theScreen.drawString(Preferences.GAME_OVER_TEXT,
				Preferences.GAME_OVER_X, Preferences.GAME_OVER_Y);
	}

}
